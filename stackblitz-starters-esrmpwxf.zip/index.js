const {
  Client,
  GatewayIntentBits,
  Events,
  REST,
  Routes,
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
} = require('discord.js');
require('dotenv').config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
  ],
});

const commands = [
  new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Create an embed with multiple fields')
    .addStringOption((option) =>
      option.setName('title').setDescription('Embed title').setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('description')
        .setDescription('Embed description (use / for newlines)')
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('colour')
        .setDescription('Embed color (Hex code)')
        .setRequired(false)
    )
    .addBooleanOption((option) =>
      option
        .setName('timestamp')
        .setDescription('Add a timestamp')
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('image_urls')
        .setDescription('Image URLs (comma separated, max 4)')
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('thumbnail_url')
        .setDescription('Thumbnail URL')
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('author_name')
        .setDescription('Author name')
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('author_url')
        .setDescription('Author URL')
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('author_profile')
        .setDescription('Author profile picture URL')
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('footer_text')
        .setDescription('Footer text')
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('footer_icon_url')
        .setDescription('Footer icon URL')
        .setRequired(false)
    ),
  new SlashCommandBuilder()
    .setName('stick')
    .setDescription(
      'Stick a message or embed to a message ID, deleting the old message after 5 seconds'
    )
    .addStringOption((option) =>
      option
        .setName('message_id')
        .setDescription('Message ID to stick to')
        .setRequired(true)
    ),
  new SlashCommandBuilder()
    .setName('field')
    .setDescription('Add up to 12 fields to an existing embed')
    .addStringOption((option) =>
      option
        .setName('message_id')
        .setDescription('Message ID of the embed to edit')
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName('fields')
        .setDescription('Fields in format: "name,value,inline (true/false);"')
        .setRequired(true)
    ),
  new SlashCommandBuilder()
    .setName('stat')
    .setDescription(
      'Create a new category and then select options for voice channel creation.'
    )
    .addStringOption((option) =>
      option
        .setName('category_name')
        .setDescription('Name for the new category')
        .setRequired(true)
    ),
];

const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

const registerCommands = async () => {
  try {
    console.log('Registering slash commands...');
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), {
      body: commands,
    });
    console.log('Slash commands registered.');
  } catch (error) {
    console.error('Error registering commands:', error);
    setTimeout(registerCommands, 5000); // Retry after 5 seconds
  }
};

registerCommands();

client.once(Events.ClientReady, () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

const stickLoops = new Map();

client.on(Events.InteractionCreate, async (interaction) => {
  if (interaction.isCommand()) {
    if (interaction.commandName === 'embed') {
      const embed = createEmbed(interaction);
      await interaction.reply({ embeds: [embed] });
    } else if (interaction.commandName === 'stick') {
      const messageId = interaction.options.getString('message_id');

      try {
        const channel = interaction.channel;
        let originalMessage = await channel.messages.fetch(messageId);

        await interaction.reply({
          content: 'Sticked! React with ✅ to stop.',
          ephemeral: true,
        });

        let lastMessage = originalMessage;
        let intervalId;

        intervalId = setInterval(async () => {
          try {
            let newMessage;

            if (lastMessage.embeds.length > 0) {
              newMessage = await channel.send({
                content: lastMessage.content || null,
                embeds: lastMessage.embeds,
              });
            } else {
              newMessage = await channel.send({
                content: lastMessage.content || '',
              });
            }

            await newMessage.react('✅');

            if (lastMessage) {
              await lastMessage.delete().catch((err) => {
                if (err.code !== 10008)
                  console.error(`Error deleting message: ${err}`);
              });
            }

            lastMessage = newMessage;
            stickLoops.set(newMessage.id, { intervalId, lastMessage });
          } catch (error) {
            console.error(`Error in stick loop: ${error}`);
            clearInterval(intervalId);
          }
        }, 5000);
      } catch (error) {
        console.error(error);
        await interaction.reply({
          content: 'Failed to stick to the message. Check the message ID.',
          ephemeral: true,
        });
      }
    } else if (interaction.commandName === 'field') {
      const messageId = interaction.options.getString('message_id');
      const fieldInput = interaction.options.getString('fields');

      try {
        const channel = interaction.channel;
        let message = await channel.messages.fetch(messageId);

        if (!message || message.embeds.length === 0) {
          return await interaction.reply({
            content: 'Message ID does not contain an embed.',
            ephemeral: true,
          });
        }

        let embed = EmbedBuilder.from(message.embeds[0]);
        const fields = parseFields(fieldInput);

        if (!fields || fields.length === 0) {
          return await interaction.reply({
            content:
              'Invalid field format. Use: `name,value,inline (true/false);`',
            ephemeral: true,
          });
        }

        if (
          embed.data.fields &&
          embed.data.fields.length + fields.length > 12
        ) {
          return await interaction.reply({
            content: 'Embeds can only have up to 12 fields.',
            ephemeral: true,
          });
        }

        embed.addFields(fields);

        await message.edit({ embeds: [embed] });
        await interaction.reply({
          content: 'Fields added successfully.',
          ephemeral: true,
        });
      } catch (error) {
        console.error(error);
        await interaction.reply({
          content: 'Failed to add fields. Check the message ID.',
          ephemeral: true,
        });
      }
    } else if (interaction.commandName === 'stat') {
      const categoryName = interaction.options.getString('category_name');

      try {
        console.log(`Creating category with name: ${categoryName}`); // Debugging log

        // Create a new category with the specified name
        const category = await interaction.guild.channels.create({
          name: categoryName,
          type: ChannelType.GuildCategory,
        });

        // Send a confirmation message
        await interaction.reply({
          content: `Category "${category.name}" created!`,
          ephemeral: true,
        });

        // After creating the category, prompt the user with options for voice channel creation
        await interaction.followUp({
          content: 'Select the options for voice channel creation:',
          components: createOptionsButtons(),
        });
      } catch (error) {
        console.error(error);
        await interaction.reply({
          content: 'Failed to create the category. Please try again.',
          ephemeral: true,
        });
      }
    }
  } else if (interaction.isButton()) {
    const [option, response] = interaction.customId.split('-');
    const channelsCreated = [];

    try {
      const categoryId = interaction.channel.parentId; // Get the parent category ID
      const category = interaction.guild.channels.cache.get(categoryId);

      if (!category || category.type !== ChannelType.GuildCategory) {
        return await interaction.reply({
          content: 'Invalid category ID provided.',
          ephemeral: true,
        });
      }

      // Create a voice channel based on the response
      if (response === 'yes') {
        let channelName = '';

        switch (option) {
          case 'banned':
            channelName = 'Banned Members';
            break;
          case 'members':
            channelName = 'Members';
            break;
          case 'bots':
            channelName = 'Bots';
            break;
          case 'all':
            channelName = 'All Members';
            break;
          case 'muted':
            channelName = 'Muted Members';
            break;
          case 'boosts':
            channelName = 'Boosts';
            break;
          default:
            return; // Ignore unrecognized options
        }

        const newChannel = await interaction.guild.channels.create({
          name: channelName,
          type: ChannelType.GuildVoice,
          parent: categoryId,
          permissionOverwrites: [
            {
              id: interaction.guild.id, // @everyone role
              deny: ['CONNECT'], // Everyone cannot connect
            },
          ],
        });

        channelsCreated.push(newChannel.name);
      }

      // Reply with the results
      await interaction.reply({
        content: `${
          response === 'yes' ? 'Created' : 'Did not create'
        } channel for ${option.replace(/_/g, ' ')}: ${option}`,
        ephemeral: true,
      });
    } catch (error) {
      console.error(error);
      await interaction.reply({
        content: 'Failed to create the channel. Please try again.',
        ephemeral: true,
      });
    }
  }
});

client.on(Events.MessageReactionAdd, async (reaction, user) => {
  if (user.bot) return;

  if (reaction.emoji.name === '✅') {
    const stickData = stickLoops.get(reaction.message.id);

    if (stickData) {
      clearInterval(stickData.intervalId);
      await stickData.lastMessage
        .delete()
        .catch((err) => console.error(`Error deleting message: ${err}`));
      stickLoops.delete(reaction.message.id);
      console.log(`Stopped stick loop for message: ${reaction.message.id}`);
    }
  }
});

// Function to create embed
const createEmbed = (interaction) => {
  const title = interaction.options.getString('title') || null;
  const description = parseNewLines(
    interaction.options.getString('description')
  );
  const color = interaction.options.getString('colour')
    ? parseInt(interaction.options.getString('colour').replace('#', ''), 16)
    : null;
  const timestamp = interaction.options.getBoolean('timestamp');
  const imageUrls =
    interaction.options
      .getString('image_urls')
      ?.split(',')
      .slice(0, 4)
      .map((url) => url.trim()) || [];
  const thumbnailUrl = interaction.options.getString('thumbnail_url') || null;
  const authorName = interaction.options.getString('author_name') || null;
  const authorUrl = interaction.options.getString('author_url') || null;
  const authorProfile = interaction.options.getString('author_profile') || null;
  const footerText = interaction.options.getString('footer_text') || null;
  const footerIconUrl =
    interaction.options.getString('footer_icon_url') || null;

  const embed = new EmbedBuilder()
    .setColor(color || 0x39423)
    .setTitle(title || null)
    .setDescription(description || null)
    .setTimestamp(timestamp ? new Date() : null)
    .setFooter(
      footerText ? { text: footerText, iconURL: footerIconUrl || null } : null
    )
    .setAuthor(
      authorName
        ? {
            name: authorName,
            url: authorUrl || null,
            iconURL: authorProfile || null,
          }
        : null
    )
    .setThumbnail(thumbnailUrl || null)
    .setImage(imageUrls.length ? imageUrls[0] : null);

  return embed;
};

// Function to parse fields
const parseFields = (text) =>
  text
    .split(';')
    .filter(Boolean)
    .map((field) => {
      const [name, value, inline] = field.split(',').map((x) => x.trim());
      return { name, value: parseNewLines(value), inline: inline === 'true' }; // Parse newlines in value
    });

// Function to parse new lines
const parseNewLines = (text) =>
  text ? text.replace(/([^/]|^)\/(?!\/)/g, '$1\n').replace(/\/\//g, '/') : null;

// Function to create buttons for options
const createOptionsButtons = () => {
  const buttonOptions = [
    { label: 'Banned Members', value: 'banned' },
    { label: 'Members', value: 'members' },
    { label: 'Bots', value: 'bots' },
    { label: 'All Members', value: 'all' },
    { label: 'Emojis', value: 'emojis' },
    { label: 'Stickers', value: 'stickers' },
    { label: 'Muted Members', value: 'muted' },
    { label: 'Boosts', value: 'boosts' },
  ];

  const rows = [];
  let currentRow = new ActionRowBuilder();

  buttonOptions.forEach((option) => {
    // Check if adding the "Yes" button exceeds the limit
    if (currentRow.components.length < 5) {
      currentRow.addComponents(
        new ButtonBuilder()
          .setCustomId(`${option.value}-yes`)
          .setLabel(`Yes: ${option.label}`)
          .setStyle(ButtonStyle.Primary)
      );
    }

    // Check if adding the "No" button exceeds the limit
    if (currentRow.components.length < 5) {
      currentRow.addComponents(
        new ButtonBuilder()
          .setCustomId(`${option.value}-no`)
          .setLabel(`No: ${option.label}`)
          .setStyle(ButtonStyle.Danger)
      );
    }

    // Push the current row to rows if it's full
    if (currentRow.components.length >= 5) {
      rows.push(currentRow); // Push the current row to rows
      currentRow = new ActionRowBuilder(); // Create a new row
    }
  });

  // Push the last row if it has components
  if (currentRow.components.length > 0) {
    rows.push(currentRow);
  }

  return rows;
};

client.login(process.env.TOKEN);
